#!/bin/bash

echo "Cit-Patents"
./cc_cit_patents.sh
echo "Kron"
./cc_kron.sh
echo "Parmat"
./cc_parmat.sh
echo "Soc-Livejournal"
./cc_soc.sh
echo "Twitter_rv"
./cc_twitter.sh
