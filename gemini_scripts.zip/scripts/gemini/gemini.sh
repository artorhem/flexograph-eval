export TOOLKIT_DIR=/mnt/Graph-MetaStudy/Graph-Benchmarks-Metastudy/GeminiGraph/toolkits
