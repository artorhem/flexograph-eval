#!/bin/bash

echo "Cit-Patents"
./pr_cit_patents.sh
echo "Kron"
./pr_kron.sh
echo "Parmat"
./pr_parmat.sh
echo "Soc-Livejournal"
./pr_soc.sh
echo "Twitter_rv"
./pr_twitter.sh
